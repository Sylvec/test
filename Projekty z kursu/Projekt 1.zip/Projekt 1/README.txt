Nie zapomnijcie dodać swojego linku do Font Awesome! :)

Jeśli ikony nie działają, to właśnie dlatego, że swój kit już usunąłem. ;) 